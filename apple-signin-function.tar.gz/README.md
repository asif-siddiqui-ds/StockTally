# 🍎 Appwrite Apple Sign-In Function

This serverless function exchanges an Apple `identityToken` for an Appwrite session.

### 🔧 Environment Variables
| Key | Example |
|-----|----------|
| APPWRITE_ENDPOINT | https://fra.cloud.appwrite.io/v1 |
| APPWRITE_PROJECT_ID | 68215c9f00161f204345 |
| APPWRITE_API_KEY | standard_b34d7b1b3b91ccf2d5e4426d4412d168f92303c4c9b5123f4c5cebd369eecd00a9831488a53447dd6026ce59da37a3b3572f47d6dcc9bcb519b0f677a9939a37d650fb6252981121e14cdd3fdf989b3da14e2e8f2f7d71c0950035a2bce1f4521b7e74fabdb9be1288b55da80fde8bdc39295bd347bcf8f750f50a8ca75e8088 |

### ▶️ Deploy
1. Zip this folder:
   ```bash
   zip -r apple-signin-function.tar.gz apple-signin-function
