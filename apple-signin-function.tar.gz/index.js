// import { Client, Account } from "node-appwrite";

// export default async ({ req, res, log }) => {
//   log("🚀 Apple Sign-In function started");

//   try {
//     const body = JSON.parse(req.body || "{}");
//     log(`📩 Received body: ${JSON.stringify(body)}`);

//     if (!body.token) {
//       return res.json({ success: false, message: "❌ Missing Apple identity token" });
//     }

//     // 🧠 Initialize Appwrite SDK
//     const client = new Client()
//       .setEndpoint(process.env.APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1")
//       .setProject(process.env.APPWRITE_PROJECT_ID || "68215c9f00161f204345")
//       .setKey(process.env.APPWRITE_API_KEY);

//     const account = new Account(client);

//     // ✅ Create a session using the Apple JWT token
//     const session = await account.createSession("apple", body.token);

//     log(`✅ Session created for user: ${session.userId}`);
//     return res.json({ success: true, session });
//   } catch (err) {
//     log(`❌ Error: ${err.message}`);
//     return res.json({ success: false, message: err.message });
//   }
// };

import { Client, ID, Query, Users } from "node-appwrite";

export default async ({ req, res, log }) => {
  log("🚀 Apple Sign-In function started");

  // --- Safe body parse (Buffer or string)
  let raw = req.body;
  if (Buffer.isBuffer(raw)) raw = raw.toString("utf8");
  let body = {};
  try { body = JSON.parse(raw || "{}"); } catch { log("⚠️ Could not parse JSON body"); }

  const appleIdToken = body.identityToken || body.token;
  const email = body.email || null;
  if (!appleIdToken) {
    log("❌ Missing Apple identity token");
    return res.json({ success: false, message: "❌ Missing Apple identity token" });
  }

  try {
    // Minimal decode (no signature verify here—to add later if you want)
    const [, payloadB64] = appleIdToken.split(".");
    const payload = JSON.parse(Buffer.from(payloadB64, "base64").toString("utf8"));
    const appleSub = payload.sub;
    const claimedEmail = payload.email ?? email ?? null;

    // Init server SDK
    const client = new Client()
      .setEndpoint(process.env.APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1")
      .setProject(process.env.APPWRITE_PROJECT_ID || "68215c9f00161f204345")
      .setKey(process.env.APPWRITE_API_KEY); // keep only in env

    const users = new Users(client);

    // 1) Find user by email if we have one
    let user = null;
    if (claimedEmail) {
      const found = await users.list([Query.equal("email", claimedEmail)]);
      user = (found.total > 0 ? found.users[0] : null);
    }

    // 2) If not found by email, try by stored appleSub in prefs
    if (!user && appleSub) {
      const found = await users.list([Query.equal("prefs.appleSub", appleSub)]);
      user = (found.total > 0 ? found.users[0] : null);
    }

    // 3) Create user if still not found
    if (!user) {
      const newId = ID.unique();
      user = await users.create(newId, claimedEmail || undefined, undefined, "Apple User");
      // store appleSub for future matches
      await users.updatePrefs(user.$id, { appleSub });
    } else {
      // ensure appleSub is stored for next time
      const prefs = user.prefs || {};
      if (!prefs.appleSub && appleSub) {
        await users.updatePrefs(user.$id, { ...prefs, appleSub });
      }
    }

    // 4) Create a short-lived Appwrite token for this user
    const token = await users.createToken(user.$id); // returns { userId, secret, expire }
    // Return userId + secret to the client; the client will exchange to a session
    return res.json({ success: true, userId: token.userId, secret: token.secret });
  } catch (err) {
    log(`❌ Error: ${err.message}`);
    return res.json({ success: false, message: err.message });
  }
};
